import type { Point, Stroke, CanvasObject, ToolType, ToolButtonObject } from '../types/types';
import { snapToGrid } from './drawUtils';

export const getCanvasPoint = (
  event: MouseEvent | TouchEvent,
  canvas: HTMLCanvasElement,
  scale: number
): Point => {
  const rect = canvas.getBoundingClientRect();
  let clientX: number;
  let clientY: number;

  if (event instanceof MouseEvent) {
    clientX = event.clientX;
    clientY = event.clientY;
  } else {
    const touch = event.touches[0];
    clientX = touch.clientX;
    clientY = touch.clientY;
  }

  return {
    x: (clientX - rect.left) / scale,
    y: (clientY - rect.top) / scale
  };
};

export const isPointInObject = (
  point: Point,
  obj: CanvasObject
): boolean => {
  const halfWidth = obj.size.width / 2;
  const halfHeight = obj.size.height / 2;

  // 회전을 고려한 점의 상대 위치 계산
  const dx = point.x - obj.position.x;
  const dy = point.y - obj.position.y;
  const rotatedX = dx * Math.cos(-obj.rotation) - dy * Math.sin(-obj.rotation);
  const rotatedY = dx * Math.sin(-obj.rotation) + dy * Math.cos(-obj.rotation);

  return (
    rotatedX >= -halfWidth &&
    rotatedX <= halfWidth &&
    rotatedY >= -halfHeight &&
    rotatedY <= halfHeight
  );
};

export const handleObjectOverlap = (
  objects: CanvasObject[],
  newObj: CanvasObject
): CanvasObject[] => {
  const updatedObjects = [...objects];
  const overlapPixels = 20; // 겹침 시 밀어내는 픽셀 수

  for (let i = 0; i < updatedObjects.length; i++) {
    const existingObj = updatedObjects[i];
    
    if (
      existingObj.overlapRule === 'displace' &&
      newObj.overlapRule === 'displace' &&
      isPointInObject(newObj.position, existingObj)
    ) {
      // 기존 객체를 위로 밀어냄
      existingObj.position.y -= overlapPixels;
    }
  }

  return updatedObjects;
};

export const createStroke = (
  points: Point[],
  tool: ToolType,
  color: string = '#000000',
  width: number = 2
): Stroke => {
  return {
    id: Date.now().toString(),
    tool,
    points,
    color,
    width
  };
};

export const createToolButton = (
  position: Point,
  toolType: ToolType
): ToolButtonObject => {
  return {
    id: Date.now().toString(),
    type: 'tool-button',
    position,
    size: { width: 50, height: 50 },
    rotation: 0,
    overlapRule: 'allow',
    zIndex: 1000,
    toolType,
    icon: toolType === 'pen' ? '✏️' : '🧹'
  };
};

export const handleDragStart = (
  event: MouseEvent | TouchEvent,
  canvas: HTMLCanvasElement,
  scale: number,
  gridSize: number
): Point => {
  const point = getCanvasPoint(event, canvas, scale);
  return snapToGrid(point, gridSize);
};

export const handleDrag = (
  event: MouseEvent | TouchEvent,
  canvas: HTMLCanvasElement,
  scale: number,
  gridSize: number,
  startPoint: Point
): Point => {
  const currentPoint = getCanvasPoint(event, canvas, scale);
  const snappedPoint = snapToGrid(currentPoint, gridSize);
  
  return {
    x: snappedPoint.x - startPoint.x,
    y: snappedPoint.y - startPoint.y
  };
}; 