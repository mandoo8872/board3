import type { CanvasState } from '../types/types';

const STORAGE_KEY = 'canvas_state';

// 로컬 스토리지 관련 함수들
export const saveToLocalStorage = (state: CanvasState): void => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (error) {
    console.error('로컬 스토리지 저장 중 오류 발생:', error);
  }
};

export const loadFromLocalStorage = (): CanvasState | null => {
  try {
    const savedState = localStorage.getItem(STORAGE_KEY);
    return savedState ? JSON.parse(savedState) : null;
  } catch (error) {
    console.error('로컬 스토리지 로드 중 오류 발생:', error);
    return null;
  }
};

// Electron 파일 시스템 관련 함수들
interface FileSystemAPI {
  saveFile: (filePath: string, data: string) => Promise<{ success: boolean; error?: string }>;
  loadFile: (filePath: string) => Promise<{ success: boolean; data?: string; error?: string }>;
  watchFile: (filePath: string) => Promise<{ success: boolean; lastModified?: number; error?: string }>;
}

const getFileSystemAPI = (): FileSystemAPI | null => {
  if (typeof window.require !== 'function') {
    return null;
  }

  const { ipcRenderer } = window.require('electron');
  return {
    saveFile: (filePath: string, data: string) => 
      ipcRenderer.invoke('save-file', filePath, data),
    loadFile: (filePath: string) => 
      ipcRenderer.invoke('load-file', filePath),
    watchFile: (filePath: string) => 
      ipcRenderer.invoke('watch-file', filePath)
  };
};

// 파일 저장
export const saveToFile = async (state: CanvasState, filePath: string): Promise<boolean> => {
  try {
    const result = await window.electron.saveToFile(state, filePath);
    return result.success;
  } catch (error) {
    console.error('파일 저장 중 오류 발생:', error);
    return false;
  }
};

// 파일 로드
export const loadFromFile = async (filePath: string): Promise<CanvasState | null> => {
  try {
    const result = await window.electron.loadFromFile(filePath);
    return result.success ? result.state : null;
  } catch (error) {
    console.error('파일 로드 중 오류 발생:', error);
    return null;
  }
};

// 파일 변경 감지
export const watchFileChanges = async (
  filePath: string,
  onFileChanged: (state: CanvasState) => void
): Promise<() => void> => {
  try {
    const result = await window.electron.watchFile(filePath);
    if (result.success) {
      window.electron.onFileChanged(onFileChanged);
      return () => {
        // TODO: 파일 감시 중지 구현
      };
    }
    return () => {};
  } catch (error) {
    console.error('파일 감시 설정 중 오류 발생:', error);
    return () => {};
  }
}; 