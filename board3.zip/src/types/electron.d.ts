interface Window {
  require: (module: string) => any;
  electron: {
    selectFile: () => Promise<{ success: boolean; filePath?: string }>;
    saveFile: () => Promise<{ success: boolean; filePath?: string }>;
    saveToFile: (state: any, filePath: string) => Promise<{ success: boolean }>;
    loadFromFile: (filePath: string) => Promise<{ success: boolean; state?: any }>;
    watchFile: (filePath: string) => Promise<{ success: boolean; watcher?: any }>;
    onFileChanged: (callback: (state: any) => void) => void;
  };
}

declare namespace NodeJS {
  interface ProcessEnv {
    NODE_ENV: 'development' | 'production';
  }
} 