export interface Position {
  x: number;
  y: number;
}

export interface Size {
  width: number;
  height: number;
}

export interface CanvasConfig {
  width: number;
  height: number;
  gridSize: number;
}

export type ToolType = 'pen' | 'eraser' | 'select' | 'text' | 'shape' | 'image';

export interface Stroke {
  id: string;
  points: Position[];
  color: string;
  width: number;
  lastModified: number;
}

export interface CanvasObject {
  id: string;
  type: 'text' | 'shape' | 'image';
  position: Position;
  size: Size;
  rotation: number;
  overlapRule: 'displace' | 'overlap' | 'hide';
  zIndex: number;
  lastModified: number;
  content?: string;
  fontSize?: number;
  fontFamily?: string;
  color?: string;
  shapeType?: 'rectangle' | 'circle' | 'triangle';
  fill?: string;
  stroke?: string;
  strokeWidth?: number;
  imageUrl?: string;
}

export interface CanvasState {
  canvas: CanvasConfig;
  objects: CanvasObject[];
  strokes: Stroke[];
  toolButtons: {
    id: string;
    position: Position;
    size: Size;
    content: string;
  }[];
  lastModified: string;
}

export interface ViewConfig {
  x: number;
  y: number;
  width: number;
  height: number;
} 