import React from 'react';
import { Box, IconButton, Tooltip } from '@mui/material';
import {
  Edit as PenIcon,
  Delete as EraserIcon,
  TextFields as TextIcon,
  Image as ImageIcon,
  CropSquare as RectangleIcon,
  RadioButtonUnchecked as CircleIcon,
  ChangeHistory as TriangleIcon
} from '@mui/icons-material';
import { ToolType } from '../types/types';

interface ToolbarProps {
  selectedTool: ToolType;
  onToolSelect: (tool: ToolType) => void;
  onObjectAdd: (type: string) => void;
  isViewMode?: boolean;
}

export const Toolbar: React.FC<ToolbarProps> = ({
  selectedTool,
  onToolSelect,
  onObjectAdd,
  isViewMode = false
}) => {
  return (
    <Box
      sx={{
        position: 'absolute',
        top: 16,
        left: 16,
        display: 'flex',
        flexDirection: 'column',
        gap: 1,
        bgcolor: 'background.paper',
        borderRadius: 1,
        p: 1,
        boxShadow: 1
      }}
    >
      <Tooltip title="연필">
        <IconButton
          color={selectedTool === 'pen' ? 'primary' : 'default'}
          onClick={() => onToolSelect('pen')}
        >
          <PenIcon />
        </IconButton>
      </Tooltip>

      <Tooltip title="지우개">
        <IconButton
          color={selectedTool === 'eraser' ? 'primary' : 'default'}
          onClick={() => onToolSelect('eraser')}
        >
          <EraserIcon />
        </IconButton>
      </Tooltip>

      {!isViewMode && (
        <>
          <Tooltip title="텍스트 추가">
            <IconButton onClick={() => onObjectAdd('text')}>
              <TextIcon />
            </IconButton>
          </Tooltip>

          <Tooltip title="이미지 추가">
            <IconButton onClick={() => onObjectAdd('image')}>
              <ImageIcon />
            </IconButton>
          </Tooltip>

          <Tooltip title="사각형 추가">
            <IconButton onClick={() => onObjectAdd('rectangle')}>
              <RectangleIcon />
            </IconButton>
          </Tooltip>

          <Tooltip title="원 추가">
            <IconButton onClick={() => onObjectAdd('circle')}>
              <CircleIcon />
            </IconButton>
          </Tooltip>

          <Tooltip title="삼각형 추가">
            <IconButton onClick={() => onObjectAdd('triangle')}>
              <TriangleIcon />
            </IconButton>
          </Tooltip>
        </>
      )}
    </Box>
  );
}; 