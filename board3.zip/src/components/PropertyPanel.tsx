import React from 'react';
import {
  Box,
  Typography,
  TextField,
  Slider,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Switch,
  FormControlLabel
} from '@mui/material';
import type { CanvasObject, TextObject, ShapeObject } from '../types/types';

interface PropertyPanelProps {
  selectedObject: CanvasObject | null;
  onObjectUpdate: (updatedObject: CanvasObject) => void;
}

const isTextObject = (obj: CanvasObject): obj is TextObject => {
  return obj.type === 'text';
};

const isShapeObject = (obj: CanvasObject): obj is ShapeObject => {
  return obj.type === 'shape';
};

export const PropertyPanel: React.FC<PropertyPanelProps> = ({
  selectedObject,
  onObjectUpdate
}) => {
  if (!selectedObject) {
    return null;
  }

  const handlePositionChange = (axis: 'x' | 'y', value: number) => {
    onObjectUpdate({
      ...selectedObject,
      position: {
        ...selectedObject.position,
        [axis]: value
      }
    });
  };

  const handleSizeChange = (axis: 'width' | 'height', value: number) => {
    onObjectUpdate({
      ...selectedObject,
      size: {
        ...selectedObject.size,
        [axis]: value
      }
    });
  };

  const handleRotationChange = (value: number) => {
    onObjectUpdate({
      ...selectedObject,
      rotation: value
    });
  };

  const handleOverlapRuleChange = (value: 'allow' | 'displace') => {
    onObjectUpdate({
      ...selectedObject,
      overlapRule: value
    });
  };

  const renderTextProperties = (obj: TextObject) => (
    <>
      <TextField
        label="텍스트"
        value={obj.content}
        onChange={(e) =>
          onObjectUpdate({
            ...obj,
            content: e.target.value
          } as TextObject)
        }
        fullWidth
        margin="normal"
      />
      <TextField
        label="글꼴 크기"
        type="number"
        value={obj.fontSize}
        onChange={(e) =>
          onObjectUpdate({
            ...obj,
            fontSize: Number(e.target.value)
          } as TextObject)
        }
        fullWidth
        margin="normal"
      />
      <FormControl fullWidth margin="normal">
        <InputLabel>글꼴</InputLabel>
        <Select
          value={obj.fontFamily}
          onChange={(e) =>
            onObjectUpdate({
              ...obj,
              fontFamily: e.target.value
            } as TextObject)
          }
        >
          <MenuItem value="Arial">Arial</MenuItem>
          <MenuItem value="Times New Roman">Times New Roman</MenuItem>
          <MenuItem value="맑은 고딕">맑은 고딕</MenuItem>
        </Select>
      </FormControl>
      <TextField
        label="색상"
        type="color"
        value={obj.color}
        onChange={(e) =>
          onObjectUpdate({
            ...obj,
            color: e.target.value
          } as TextObject)
        }
        fullWidth
        margin="normal"
      />
    </>
  );

  const renderShapeProperties = (obj: ShapeObject) => (
    <>
      <TextField
        label="채우기 색상"
        type="color"
        value={obj.fill}
        onChange={(e) =>
          onObjectUpdate({
            ...obj,
            fill: e.target.value
          } as ShapeObject)
        }
        fullWidth
        margin="normal"
      />
      <TextField
        label="테두리 색상"
        type="color"
        value={obj.stroke}
        onChange={(e) =>
          onObjectUpdate({
            ...obj,
            stroke: e.target.value
          } as ShapeObject)
        }
        fullWidth
        margin="normal"
      />
      <TextField
        label="테두리 두께"
        type="number"
        value={obj.strokeWidth}
        onChange={(e) =>
          onObjectUpdate({
            ...obj,
            strokeWidth: Number(e.target.value)
          } as ShapeObject)
        }
        fullWidth
        margin="normal"
      />
    </>
  );

  return (
    <Box
      sx={{
        position: 'absolute',
        top: 16,
        right: 16,
        width: 300,
        bgcolor: 'background.paper',
        borderRadius: 1,
        p: 2,
        boxShadow: 1
      }}
    >
      <Typography variant="h6" gutterBottom>
        속성
      </Typography>

      <TextField
        label="X 위치"
        type="number"
        value={selectedObject.position.x}
        onChange={(e) => handlePositionChange('x', Number(e.target.value))}
        fullWidth
        margin="normal"
      />

      <TextField
        label="Y 위치"
        type="number"
        value={selectedObject.position.y}
        onChange={(e) => handlePositionChange('y', Number(e.target.value))}
        fullWidth
        margin="normal"
      />

      <TextField
        label="너비"
        type="number"
        value={selectedObject.size.width}
        onChange={(e) => handleSizeChange('width', Number(e.target.value))}
        fullWidth
        margin="normal"
      />

      <TextField
        label="높이"
        type="number"
        value={selectedObject.size.height}
        onChange={(e) => handleSizeChange('height', Number(e.target.value))}
        fullWidth
        margin="normal"
      />

      <Typography gutterBottom>회전</Typography>
      <Slider
        value={selectedObject.rotation}
        onChange={(_, value) => handleRotationChange(value as number)}
        min={0}
        max={360}
        step={1}
        valueLabelDisplay="auto"
      />

      <FormControl fullWidth margin="normal">
        <InputLabel>겹침 규칙</InputLabel>
        <Select
          value={selectedObject.overlapRule}
          onChange={(e) =>
            handleOverlapRuleChange(e.target.value as 'allow' | 'displace')
          }
        >
          <MenuItem value="allow">허용</MenuItem>
          <MenuItem value="displace">밀어내기</MenuItem>
        </Select>
      </FormControl>

      {isTextObject(selectedObject) && renderTextProperties(selectedObject)}
      {isShapeObject(selectedObject) && renderShapeProperties(selectedObject)}
    </Box>
  );
}; 