import React, { useRef, useEffect, useState } from 'react';
import type { CanvasState, Point, Stroke, CanvasObject, ToolType } from '../types/types';
import { drawStroke, drawObject, calculateScale } from '../lib/drawUtils';
import { getCanvasPoint, createStroke, handleObjectOverlap } from '../lib/eventHandlers';

interface CanvasProps {
  state: CanvasState;
  onStateChange: (newState: CanvasState) => void;
  isViewMode?: boolean;
  viewConfig?: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
}

export const Canvas: React.FC<CanvasProps> = ({
  state,
  onStateChange,
  isViewMode = false,
  viewConfig
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [scale, setScale] = useState(1);
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentStroke, setCurrentStroke] = useState<Stroke | null>(null);
  const [selectedTool, setSelectedTool] = useState<ToolType>('pen');

  // 캔버스 크기 조정
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const updateCanvasSize = () => {
      const container = canvas.parentElement;
      if (!container) return;

      const containerWidth = container.clientWidth;
      const containerHeight = container.clientHeight;

      // 캔버스 크기를 컨테이너에 맞춤
      canvas.width = containerWidth;
      canvas.height = containerHeight;

      // 스케일 계산
      const newScale = calculateScale(
        state.canvas.width,
        state.canvas.height,
        containerWidth,
        containerHeight
      );
      setScale(newScale);
    };

    updateCanvasSize();
    window.addEventListener('resize', updateCanvasSize);
    return () => window.removeEventListener('resize', updateCanvasSize);
  }, [state.canvas.width, state.canvas.height]);

  // 렌더링
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // 캔버스 초기화
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // 뷰 모드일 경우 뷰 영역만 렌더링
    if (isViewMode && viewConfig) {
      ctx.save();
      ctx.beginPath();
      ctx.rect(
        viewConfig.x * scale,
        viewConfig.y * scale,
        viewConfig.width * scale,
        viewConfig.height * scale
      );
      ctx.clip();
    }

    // 객체 렌더링
    state.objects.forEach(obj => {
      drawObject(ctx, obj, scale);
    });

    // 스트로크 렌더링
    state.strokes.forEach(stroke => {
      drawStroke(ctx, stroke, scale);
    });

    // 현재 그리는 스트로크 렌더링
    if (currentStroke) {
      drawStroke(ctx, currentStroke, scale);
    }

    if (isViewMode && viewConfig) {
      ctx.restore();
    }
  }, [state, currentStroke, scale, isViewMode, viewConfig]);

  // 마우스/터치 이벤트 핸들러
  const handlePointerDown = (event: React.MouseEvent | React.TouchEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const point = getCanvasPoint(event.nativeEvent, canvas, scale);
    setIsDrawing(true);
    setCurrentStroke(createStroke([point], selectedTool));
  };

  const handlePointerMove = (event: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing || !currentStroke) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const point = getCanvasPoint(event.nativeEvent, canvas, scale);
    setCurrentStroke({
      ...currentStroke,
      points: [...currentStroke.points, point]
    });
  };

  const handlePointerUp = () => {
    if (!isDrawing || !currentStroke) return;

    setIsDrawing(false);
    const newState: CanvasState = {
      ...state,
      strokes: [...state.strokes, currentStroke]
    };
    onStateChange(newState);
    setCurrentStroke(null);
  };

  return (
    <canvas
      ref={canvasRef}
      onMouseDown={handlePointerDown}
      onMouseMove={handlePointerMove}
      onMouseUp={handlePointerUp}
      onMouseLeave={handlePointerUp}
      onTouchStart={handlePointerDown}
      onTouchMove={handlePointerMove}
      onTouchEnd={handlePointerUp}
      style={{
        touchAction: 'none',
        userSelect: 'none',
        WebkitUserSelect: 'none'
      }}
    />
  );
}; 